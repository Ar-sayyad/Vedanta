<center><footer class="footer"> &COPY;  <span id="year">2018</span>
  <script>
    document.getElementById("year").innerHTML = new Date().getFullYear();
  </script> Design & Developed by <a target="_blank" href="https://www.ecgit.com/">ECGIT</a></footer></center>