 <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary"><?php echo $title;?></h3>
        </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
                <li class="breadcrumb-item active"><?php echo $title;?></li>
            </ol>
        </div>
 </div>